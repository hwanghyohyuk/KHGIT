package exception.silsub1;

public class CharCheckException extends Exception {

	public CharCheckException(String message){
		super(message);
	}
}
