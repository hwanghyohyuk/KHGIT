package exception.silsub2;

public class NumberRangeException extends Exception{
	
	public NumberRangeException(String message){
		super(message);
	}

}
