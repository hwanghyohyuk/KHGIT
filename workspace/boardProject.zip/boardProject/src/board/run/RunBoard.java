package board.run;

import board.view.BoardMenu;

public class RunBoard {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new BoardMenu().mainMenu();
	}

}
