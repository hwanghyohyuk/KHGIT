package productManager.main;

import productManager.view.ManagerView;

public class run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new ManagerView();
	}

}
