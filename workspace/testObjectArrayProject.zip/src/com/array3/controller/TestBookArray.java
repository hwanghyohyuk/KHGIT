package com.array3.controller;

import com.oop.silsub.model.BookManager;

public class TestBookArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BookManager bm = new BookManager();
		bm.menu();
		System.out.println("프로그램을 종료합니다.");
	}

}
