package inherit.polymorphism.model;

public abstract class Shape {
	abstract public double area();
	abstract public double perimeter();
}
